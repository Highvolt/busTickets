/** Automatically generated file. DO NOT MODIFY */
package pt.fe.up.cmov.validator;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}